document.addEventListener("DOMContentLoaded", () => {
  const tabs = document.querySelectorAll(".tab-link");
  const contents = document.querySelectorAll(".tab-content");

  tabs.forEach((tab, index) => {
    tab.addEventListener("click", (e) => {
      e.preventDefault();
      contents.forEach(c => c.classList.remove("active"));
      contents[index].classList.add("active");
    });
  });

  // Job list example
  const jobs = [
    {title:"Retail Cashier", company:"ShopRight Durban"},
    {title:"Apprentice Electrician", company:"Durban Electrics"},
    {title:"Intern - Graphic Design", company:"Creative KZN"},
    {title:"Community Health Worker", company:"KZN Health Dept"},
    {title:"Junior Accountant", company:"Finance Solutions KZN"}
  ];

  const jobList = document.getElementById('job-list');
  if(jobList){
    jobs.forEach(job => {
      const li = document.createElement('li');
      li.innerHTML = `<strong>${job.title}</strong> at ${job.company}`;
      jobList.appendChild(li);
    });
  }

  // Contact form alert
  const contactForm = document.getElementById('contact-form');
  if(contactForm){
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      alert("Your message has been sent. We will contact you soon!");
      contactForm.reset();
    });
  }
});